package State;

public enum State {
	
	Apressed,ChangeMinute,ChangeHour,Running,Bpressed;

}
