package Views;

public class main {

	public static void main(String[] args) {
		new digitalFrame();
		new analogicoFrame();
		new botoesFrame();
	}

}
